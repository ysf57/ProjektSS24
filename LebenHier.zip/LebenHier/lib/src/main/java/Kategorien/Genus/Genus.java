package Kategorien.Genus;

import jakarta.persistence.*;

@Entity
public class Genus {
    @Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

    private String name;

	public Genus(String name) {
		name = name;
	}

	public Genus() {
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}



}

//Yusuf Atik
