package Kategorien.Genus;


import org.springframework.data.repository.CrudRepository;

public interface GenusRepository extends CrudRepository<Genus, Long> {
}

//Yusuf Atik
