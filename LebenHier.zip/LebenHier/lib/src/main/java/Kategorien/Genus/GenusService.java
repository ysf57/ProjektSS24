package Kategorien.Genus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GenusService {
    @Autowired
    private GenusRepository genusRepository;

    public List<Genus> getAllGenuses() {
        return (List<Genus>) genusRepository.findAll();
    }


    public Genus getGenusById(Long id) {
        return genusRepository.findById(id).orElse(null);
    }


    public void saveGenus(Genus genus) {
        genusRepository.save(genus);
    }


    public Genus updateGenus(Long id, Genus updateGenus) {
        Genus genus = genusRepository.findById(id).orElse(null);
        if (genus != null) {
            genus.setName(updateGenus.getName());
        }
        return genusRepository.save(genus);
    }

    public void deleteGenus(Long id) {
        genusRepository.deleteById(id);
    }
}

//Yusuf Atik
