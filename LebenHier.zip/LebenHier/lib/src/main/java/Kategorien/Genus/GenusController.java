package Kategorien.Genus;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/genus")
public class GenusController {
    @Autowired
    private GenusService genusService;

    @GetMapping
    public List<Genus> getAllGenuses() {
        return genusService.getAllGenuses();
    }

    @GetMapping("/genus/{id}")
    public Genus getGenusById(@PathVariable Long id) {
        return genusService.getGenusById(id);
    }

    @PostMapping
    public void createGenus(@RequestBody Genus genus) {
        genusService.saveGenus(genus);
    }


    @PutMapping("/genus/{id}")
    public void updateGenus(@PathVariable Long id, @RequestBody Genus genus) {

        genusService.updateGenus(id, genus);
    }


    @RequestMapping(method=RequestMethod.DELETE, value="/genus/{id}")
    public void deleteTiere(@PathVariable Long id) {
        genusService.deleteGenus(id);
    }
}

//Yusuf Atik
