package Kategorien.Tier;

import org.springframework.beans.factory.annotation.Autowired;



import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TierService {
   
	@Autowired
    private TierRepository tierRepository;

	//Alle Animal abrufen
    public List<Tier> findAllTier() {
        return (List<Tier>) tierRepository.findAll();
    }


    public Tier saveTier(Tier tier) {
        return tierRepository.save(tier);
    }


    public Tier updateTier(Long id, Tier updateTier) {
        Tier tier = tierRepository.findById(id).orElse(null);
    		if (tier != null) {
    			tier.setAlter(updateTier.getAlter());
    			tier.setGroesse(updateTier.getGroesse());
    			tier.setGewicht(updateTier.getGewicht());
    			tier.setGeschlecht(updateTier.getGeschlecht());
    		}
    	return tierRepository.save(tier);
    }



    public void deleteTier(Long id) {
    	tierRepository.deleteById(id);
    }
}


//Yusuf Yavuz