package Kategorien.Tier;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/tiere")
public class TierController {
    @Autowired
    private TierService tierService;

    @GetMapping
    public List<Tier> getAllTier() {
        return tierService.findAllTier();
    }

    @PostMapping
    public Tier createTier(@RequestBody Tier tier) {
        return tierService.saveTier(tier);
    }

    
    @PutMapping("/tiere/{id}")
	public void updateTier(@PathVariable Long id, @RequestBody Tier tier) {

        tierService.updateTier(id, tier);
    }

    
    @RequestMapping(method=RequestMethod.DELETE, value="/tiere/{id}") 
	public void deleteTiere(@PathVariable Long id) {
    	tierService.deleteTier(id); 
	}
    

}

//Yusuf Yavuz
