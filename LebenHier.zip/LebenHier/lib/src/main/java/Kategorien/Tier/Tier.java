package Kategorien.Tier;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Tier {
    @Id
    @GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)
    private int id;
    private String Geschlecht;
    private String Groesse;
    private String Gewicht;
    private String Alter;



	public String getGeschlecht() {
		return Geschlecht;
	}
	public void setGeschlecht(String Geschlecht) {
		this.Geschlecht = Geschlecht;
	}


	public String getGroesse() {
		return Groesse;
	}
	public void setGroesse(String Groesse) {
		this.Groesse = Groesse;
	}


	public String getGewicht() {
		return Gewicht;
	}
	public void setGewicht(String Gewicht) {
		this.Gewicht = Gewicht;
	}


	public String getAlter() {return Alter;}
	public void setAlter(String Alter) {
		this.Alter = Alter;
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}

//Yusuf Yavuz

