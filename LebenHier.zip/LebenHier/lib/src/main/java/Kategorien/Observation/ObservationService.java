package Kategorien.Observation;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ObservationService {
    @Autowired
    private ObservationRepository observationRepository;

    public List<Observation> findAll() {
        return (List<Observation>) observationRepository.findAll();
    }

    public Observation save(Observation observation) {
        return observationRepository.save(observation);
    }





    public Observation updateObservation (Long id, Observation updateObservation) {

        Observation observation = observationRepository.findById(id).orElse(null);
        if (observation != null) {
            observation.setObservationsDatum(updateObservation.getObservationsDatum());
            observation.setTierId(updateObservation.getTierId());
            observation.setStandortId(updateObservation.getStandortId());
        }

        return observationRepository.save(observation);
    }







    public void deleteById(Long id) {
        observationRepository.deleteById(id);
    }
}

//Yusuf Atik
