package Kategorien.Observation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/observation")
public class ObservationController {
    @Autowired
    private ObservationService observationService;

    @GetMapping
    public List<Observation> getAllObservation() {
        return observationService.findAll();
    }


    @PostMapping
    public Observation createObservation(@RequestBody Observation observed) {
        return observationService.save(observed);
    }


    @PutMapping("/observation/{id}")
    public void updateObservation(@PathVariable Long id, @RequestBody Observation observation) {

        observationService.updateObservation(id, observation);
    }


    @RequestMapping(method=RequestMethod.DELETE, value="/observation/{id}")
    public void deleteTiere(@PathVariable Long id) {
        observationService.deleteById(id);
    }
}

//Yusuf Atik
