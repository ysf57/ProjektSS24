package Kategorien.Observation;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Observation {
    @Id
    @GeneratedValue(strategy = jakarta.persistence.GenerationType.IDENTITY)

    private Long id;
    public String ObservationsDatum;
    private int TierId;
    private int StandortId;



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    
    public String getObservationsDatum() {
        return ObservationsDatum;
    }

    public void setObservationsDatum(String observationsDatum) {
        this.ObservationsDatum = observationsDatum;
    }



    public int getTierId() {
        return TierId;
    }

    public void setTierId(int tierId) {
        this.TierId = tierId;
    }



    public int getStandortId() {
        return StandortId;
    }

    public void setStandortId(int standortId) {
        this.StandortId = standortId;
       }



}

//Yusuf Atik
