package Kategorien.Standort;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/standorte")
public class StandortController {
    @Autowired
    private StandortService standortService;

    @GetMapping
    public List<Standort> getAllStandorte() {
        return standortService.findAll();
    }

    @PostMapping
    public Standort createStandort(@RequestBody Standort standort) {
        return standortService.save(standort);
    }

    @PutMapping("/standorte/{id}")
    public void updateStandort(@PathVariable Long id, @RequestBody Standort standort) {

        standortService.updateStandort(id, standort);
    }



    @RequestMapping(method=RequestMethod.DELETE, value="/standorte/{id}")
    public void deleteTiere(@PathVariable Long id) {
        standortService.deleteById(id);
    }

}

//Yusuf Yavuz