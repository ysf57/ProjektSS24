package Kategorien.Standort;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.sql.Date;
import java.sql.Time;

@Entity
public class Standort {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private int id;

    private Time Uhrzeit;
    private Date Datum;
    private String Titel;
    private String Beschreibung;

	public Standort(Time uhrzeit, Date datum, String titel, String beschreibung) {
		Uhrzeit = uhrzeit;
		Datum = datum;
		Titel = titel;
		Beschreibung = beschreibung;
	}

	public Standort() {
	}

	public Time getUhrzeit() {
		return Uhrzeit;
	}
	public void setUhrzeit(Time Uhrzeit) {
		this.Uhrzeit = Uhrzeit;
	}
	
	
	public Date getDatum() {
		return Datum;
	}
	public void setDatum(Date Datum) {
		this.Datum = Datum;
	}
	
	public String getTitel() {
		return Titel;
	}
	public void setTitel(String Titel) {
		this.Titel = Titel;
	}
	
	
	public String getBeschreibung() {
		return Beschreibung;
	}
	public void setBeschreibung(String Beschreibung) {
		this.Beschreibung = Beschreibung;
	}



	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

}

//Yusuf Yavuz