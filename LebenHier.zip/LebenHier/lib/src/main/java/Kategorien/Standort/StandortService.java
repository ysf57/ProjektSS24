package Kategorien.Standort;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StandortService {
    @Autowired
    private StandortRepository standortRepository;

    public List<Standort> findAll() {
        return (List<Standort>) standortRepository.findAll();
    }

    public Standort save(Standort standort) {
        return standortRepository.save(standort);
    }



    public Standort updateStandort(Long id, Standort updateStandort) {
        Standort standort = standortRepository.findById(id).orElse(null);
        if (standort != null) {
            standort.setUhrzeit(updateStandort.getUhrzeit());
            standort.setBeschreibung(updateStandort.getBeschreibung());
            standort.setDatum(updateStandort.getDatum());
            standort.setTitel(updateStandort.getTitel());
        }

            return standortRepository.save(standort);
    }

    public void deleteById(Long id) {standortRepository.deleteById(id);
    }
}

//Yusuf Yavuz

